		<footer>
			<span class="authorfooter">
				&copy; <a itemprop="url" href="http://pdostal.cz/">Pavel Dostál</a>
				(<a href="mailto:pdostal@pdostal.cz">pdostal@pdostal.cz</a>)
			</span><br />
			<span class="wordpressfooter">
				Powered by <a href="http://wordpress.org/">Wordpress</a>
			</span>
		</footer>
		<?php wp_footer(); ?>
	</body>
</html>